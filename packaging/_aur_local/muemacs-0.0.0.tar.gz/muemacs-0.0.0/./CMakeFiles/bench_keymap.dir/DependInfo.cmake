
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/mod/personal/PROGRAMMING/SYSTEM PROGRAMS/LINUX/μEmacs/tests/bench/keymap_bench.c" "CMakeFiles/bench_keymap.dir/tests/bench/keymap_bench.c.o" "gcc" "CMakeFiles/bench_keymap.dir/tests/bench/keymap_bench.c.o.d"
  "" "build/bin/bench_keymap" "gcc" "CMakeFiles/bench_keymap.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
