file(REMOVE_RECURSE
  "CMakeFiles/bench_keymap.dir/link.d"
  "CMakeFiles/bench_keymap.dir/tests/bench/keymap_bench.c.o"
  "CMakeFiles/bench_keymap.dir/tests/bench/keymap_bench.c.o.d"
  "build/bin/bench_keymap"
  "build/bin/bench_keymap.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/bench_keymap.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
