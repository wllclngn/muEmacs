file(REMOVE_RECURSE
  "CMakeFiles/bench_utf8.dir/link.d"
  "CMakeFiles/bench_utf8.dir/tests/bench/utf8_bench.c.o"
  "CMakeFiles/bench_utf8.dir/tests/bench/utf8_bench.c.o.d"
  "build/bin/bench_utf8"
  "build/bin/bench_utf8.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/bench_utf8.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
