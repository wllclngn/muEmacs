# Empty compiler generated dependencies file for bench_utf8.
# This may be replaced when dependencies are built.
