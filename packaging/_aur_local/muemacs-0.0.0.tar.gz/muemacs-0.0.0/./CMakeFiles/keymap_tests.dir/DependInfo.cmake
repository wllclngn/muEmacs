
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/mod/personal/PROGRAMMING/SYSTEM PROGRAMS/LINUX/μEmacs/tests/run_keymap_tests.c" "CMakeFiles/keymap_tests.dir/tests/run_keymap_tests.c.o" "gcc" "CMakeFiles/keymap_tests.dir/tests/run_keymap_tests.c.o.d"
  "/home/mod/personal/PROGRAMMING/SYSTEM PROGRAMS/LINUX/μEmacs/tests/test_help_prefix_toggle.c" "CMakeFiles/keymap_tests.dir/tests/test_help_prefix_toggle.c.o" "gcc" "CMakeFiles/keymap_tests.dir/tests/test_help_prefix_toggle.c.o.d"
  "/home/mod/personal/PROGRAMMING/SYSTEM PROGRAMS/LINUX/μEmacs/tests/test_keymap.c" "CMakeFiles/keymap_tests.dir/tests/test_keymap.c.o" "gcc" "CMakeFiles/keymap_tests.dir/tests/test_keymap.c.o.d"
  "/home/mod/personal/PROGRAMMING/SYSTEM PROGRAMS/LINUX/μEmacs/tests/test_keymap_defaults.c" "CMakeFiles/keymap_tests.dir/tests/test_keymap_defaults.c.o" "gcc" "CMakeFiles/keymap_tests.dir/tests/test_keymap_defaults.c.o.d"
  "/home/mod/personal/PROGRAMMING/SYSTEM PROGRAMS/LINUX/μEmacs/tests/test_utils.c" "CMakeFiles/keymap_tests.dir/tests/test_utils.c.o" "gcc" "CMakeFiles/keymap_tests.dir/tests/test_utils.c.o.d"
  "" "build/bin/keymap_tests" "gcc" "CMakeFiles/keymap_tests.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
