file(REMOVE_RECURSE
  "CMakeFiles/keymap_tests.dir/link.d"
  "CMakeFiles/keymap_tests.dir/tests/run_keymap_tests.c.o"
  "CMakeFiles/keymap_tests.dir/tests/run_keymap_tests.c.o.d"
  "CMakeFiles/keymap_tests.dir/tests/test_help_prefix_toggle.c.o"
  "CMakeFiles/keymap_tests.dir/tests/test_help_prefix_toggle.c.o.d"
  "CMakeFiles/keymap_tests.dir/tests/test_keymap.c.o"
  "CMakeFiles/keymap_tests.dir/tests/test_keymap.c.o.d"
  "CMakeFiles/keymap_tests.dir/tests/test_keymap_defaults.c.o"
  "CMakeFiles/keymap_tests.dir/tests/test_keymap_defaults.c.o.d"
  "CMakeFiles/keymap_tests.dir/tests/test_utils.c.o"
  "CMakeFiles/keymap_tests.dir/tests/test_utils.c.o.d"
  "build/bin/keymap_tests"
  "build/bin/keymap_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/keymap_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
