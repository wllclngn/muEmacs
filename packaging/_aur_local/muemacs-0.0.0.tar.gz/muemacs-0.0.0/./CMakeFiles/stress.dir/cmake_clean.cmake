file(REMOVE_RECURSE
  "CMakeFiles/stress"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/stress.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
