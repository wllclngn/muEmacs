# Empty custom commands generated dependencies file for stress.
# This may be replaced when dependencies are built.
