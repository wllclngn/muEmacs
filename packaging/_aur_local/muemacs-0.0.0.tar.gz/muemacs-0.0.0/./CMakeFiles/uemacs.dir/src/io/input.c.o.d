CMakeFiles/uemacs.dir/src/io/input.c.o: \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/src/io/input.c \
 /usr/include/stdc-predef.h /usr/include/stdio.h \
 /usr/include/bits/libc-header-start.h /usr/include/features.h \
 /usr/include/features-time64.h /usr/include/bits/wordsize.h \
 /usr/include/bits/timesize.h /usr/include/sys/cdefs.h \
 /usr/include/bits/long-double.h /usr/include/gnu/stubs.h \
 /usr/include/gnu/stubs-64.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/stddef.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/stdarg.h \
 /usr/include/bits/types.h /usr/include/bits/typesizes.h \
 /usr/include/bits/time64.h /usr/include/bits/types/__fpos_t.h \
 /usr/include/bits/types/__mbstate_t.h \
 /usr/include/bits/types/__fpos64_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/floatn.h \
 /usr/include/bits/floatn-common.h /usr/include/bits/stdio2-decl.h \
 /usr/include/bits/stdio.h /usr/include/bits/stdio2.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/stdbool.h \
 /usr/include/unistd.h /usr/include/bits/posix_opt.h \
 /usr/include/bits/environments.h /usr/include/bits/confname.h \
 /usr/include/bits/getopt_posix.h /usr/include/bits/getopt_core.h \
 /usr/include/bits/unistd.h /usr/include/bits/unistd-decl.h \
 /usr/include/bits/unistd_ext.h /usr/include/linux/close_range.h \
 /usr/include/sys/wait.h /usr/include/signal.h \
 /usr/include/bits/signum-generic.h /usr/include/bits/signum-arch.h \
 /usr/include/bits/types/sig_atomic_t.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timespec.h /usr/include/bits/endian.h \
 /usr/include/bits/endianness.h /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/siginfo_t.h /usr/include/bits/types/__sigval_t.h \
 /usr/include/bits/siginfo-arch.h /usr/include/bits/siginfo-consts.h \
 /usr/include/bits/siginfo-consts-arch.h \
 /usr/include/bits/types/sigval_t.h /usr/include/bits/types/sigevent_t.h \
 /usr/include/bits/sigevent-consts.h /usr/include/bits/sigaction.h \
 /usr/include/bits/sigcontext.h /usr/include/bits/types/stack_t.h \
 /usr/include/sys/ucontext.h /usr/include/bits/sigstack.h \
 /usr/include/bits/sigstksz.h /usr/include/bits/ss_flags.h \
 /usr/include/bits/types/struct_sigstack.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/bits/sigthread.h \
 /usr/include/bits/signal_ext.h /usr/include/bits/waitflags.h \
 /usr/include/bits/waitstatus.h /usr/include/bits/types/idtype_t.h \
 /usr/include/stdlib.h /usr/include/bits/types/locale_t.h \
 /usr/include/bits/types/__locale_t.h /usr/include/sys/types.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/timer_t.h /usr/include/bits/stdint-intn.h \
 /usr/include/endian.h /usr/include/bits/byteswap.h \
 /usr/include/bits/uintn-identity.h /usr/include/sys/select.h \
 /usr/include/bits/select.h /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/select2.h /usr/include/bits/select-decl.h \
 /usr/include/alloca.h /usr/include/bits/stdlib-bsearch.h \
 /usr/include/bits/stdlib-float.h /usr/include/bits/stdlib.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/stdatomic.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/estruct.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/config.h \
 /usr/include/string.h /usr/include/strings.h \
 /usr/include/bits/strings_fortified.h \
 /usr/include/bits/string_fortified.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/15.2.1/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/wchar.h \
 /usr/include/bits/stdint-uintn.h /usr/include/bits/stdint-least.h \
 /usr/include/assert.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/../μemacs/terminal_ops.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/../μemacs/core.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/c23_compat.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/edef.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/efunc.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/undo.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/wrapper.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/file_utils.h \
 /usr/include/time.h /usr/include/bits/time.h /usr/include/bits/timex.h \
 /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/struct_itimerspec.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/internal/string_safe.h \
 /home/mod/personal/PROGRAMMING/SYSTEM\ PROGRAMS/LINUX/μEmacs/include/μemacs/keymap.h
