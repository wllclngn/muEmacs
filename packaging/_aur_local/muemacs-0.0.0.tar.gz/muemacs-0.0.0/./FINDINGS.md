# μEmacs — Repository Findings (Health + Scope Review)

## Executive Summary
- Core builds cleanly on modern Linux (C23), runs fast, and passes the integration suite.
- Prior interactive test timeouts were due to Expect/PTY usage in non‑interactive CI; we gated that and added non‑interactive coverage.
- User UX friction around “fill column” (Emacs jargon) is addressed with a clear `set-column-width` command and JSON settings.
- A handful of source files are not included in the build; likely experimental or retired.
- No unsafe libc usage detected in active code paths; safe wrappers are in place.

## Integration Tests — State and Improvements
- Working issues observed:
  - Agents timed out running interactive Expect scripts without a TTY.
  - M‑x (ESC x) was only bound on uppercase ‘X’, and numeric‑arg → M‑x flow was awkward.
- Fixes and additions:
  - Expect/PTY gating: interactive scripts run only when explicitly enabled; otherwise skipped.
  - New non‑interactive coverage:
    - Key decode edges (Meta on punctuation/digits; Kitty CSI u variants)
    - M‑x command flow (docmd path with numeric args)
    - Real‑text paragraph reflow using Project Gutenberg Poe (wrap at width and verify)
  - Numeric‑arg flow fix: after Meta digits, a subsequent ESC is combined as Meta (M‑80 M‑x works).
  - Lowercase binding: `META|'x'` now invokes `execute-named-command`.

## UX and Settings — Changes Made
- Replaced Emacs‑ism with plain language:
  - Removed `set-fill-column` in favor of `set-column-width` (prompts for a number; enables wrap).
  - Kept `writing-mode` (one‑shot wrap at 80 or numeric width).
  - Bound `C-x W` → `set-column-width`.
- JSON user settings (no dependencies):
  - Location: `~/.config/uemacs/settings.json` (optional; loaded if present).
  - No files are created at startup; users can create/save via commands.
  - Supported keys:
    - Core: `column_width` (number), `wrap` (bool)
    - Visual helpers: `ruler` (bool), `rulercol` (number), `highlightline` (bool), `hilinestyle` (0..3), `rulerstyle` (0..3)
    - Modeline toggles: `modeline_show_git`, `modeline_show_stats`, `modeline_show_modes`, `modeline_show_position` (bools)
  - Convenience commands:
    - `set-column-width` (prompt), `save-settings` (creates file), `open-user-config` (creates file), `list-settings`

## Orphaned / Not‑Built Sources
These compile units are present but not referenced by `CMakeLists.txt`:
- `src/core/docker_control.c`
- `src/core/menu_buffer.c`
- `src/core/menu_chat.c`
- `src/core/menu_hub.c`
- `src/core/menu_profile.c`
- `src/core/mx_neuroxus.c`
- `src/core/neuroxus_logo.c`
- `src/core/protocol_bridge.c`
- `src/core/query_ai.c`

Zero‑length test stubs:
- `tests/test_accessibility.c`
- `tests/test_error_handling.c`
- `tests/test_i18n.c`
- `tests/test_fuzz_escape_utf8.c`
- `tests/test_external_integration.c`
- `tests/test_protocol_bridge.c`

Recommendation: If experimental, move to `experiments/` (with a short README) or remove to reduce noise.

## Legacy / Non‑C23 Footprints
- Build/tooling: CMake enforces C23; code compiles under C23.
- Legacy references appear in comments and history/docs only; no legacy drivers are built.
- `config.h` sets legacy macros (`WIN32`, `MSDOS`, `VMS`, `IBMPC`) to 0 — benign.

## Safety / “Instantaneous & Atomic” Notes
- Safe string patterns: consolidated in `string_safe`/`string_utils`; no active `strcpy/strcat/sprintf/gets/strdup` usage.
- Atomic patterns:
  - Keymap stats/lookups, terminal/display caches, undo/kill ring metadata use atomic counters or caches.
- Minor cleanups (style warnings):
  - `settings.c` and `eval.c` emit “misleading‑indentation” warnings due to two one‑line `if` clauses; semantics are correct but can be tidied.

## Documentation Alignment
- README updated to:
  - Reflect M‑x prompt behavior and numeric args.
  - Prefer `set-column-width`; remove `set-fill-column` references.
  - Keep `writing-mode` as a one‑shot helper.

## Recommendations (for your guidance)
- Orphans: Move the non‑built `src/core/*` files to `experiments/` with a brief note, or remove.
- Tests: Either remove or implement the zero‑length stubs; empty files confuse health checks.
- Warnings: Fix the two “misleading‑indentation” warnings (tiny style tweak).
- Scope: Consider adding a small “Project Scope” section to README: Linux‑only, no legacy drivers, drop‑in philosophy.
- Settings: If desired, extend JSON to a few more toggles later, but avoid theme/DSL feature creep.

## Quick Command Cheatsheet (post‑changes)
- Set width: `C-x W` or `M-x set-column-width` → type number
- One‑shot wrap: `M-x writing-mode` (80) or `M-100 M-x writing-mode`
- Save JSON: `M-x save-settings`
- Open JSON: `M-x open-user-config`
- List current: `M-x list-settings`

## Appendix — What Changed in Code (High‑level)
- Added: `src/config/settings.c` (+ wiring in `CMakeLists.txt`/names/binds)
- Removed: `set-fill-column` command and binding; replaced with `set-column-width`
- Fixed: M‑x lowercase binding; numeric‑arg + M‑x flow; README alignment.
- Modeline: Added on/off gates for git/stats/modes/position via JSON.
- Tests: Added key‑decode edges, M‑x flow, Poe paragraph reflow; gated Expect.
