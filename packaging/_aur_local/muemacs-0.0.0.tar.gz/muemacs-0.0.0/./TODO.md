# μEmacs (C23, Linux) – Final TODO

This is a focused, modern TODO for μEmacs as a C23, Linux‑only terminal editor. It replaces prior sprawling lists and aligns with completed work and the current direction.

## Completed
- C-h default restored to Backspace; help via `M-?` and `M-x describe-*`.
- Optional C-h help prefix (off by default) with `enable-help-prefix` / `disable-help-prefix`.
- Bracketed paste parser with stress/fuzz coverage; macro record bypass during paste.
- Hash‑based hierarchical keymaps with atomic publication/lookup; fast unit tests.
- Full integration suite green; expect scripts wired (skipped if no PTY).
- README updated to document help prefix behavior and persistence.
 - Runtime bind/unbind synchronize modern keymaps; legacy `keytab` retained only for one‑shot import/listing.
 - `M-x keymap-stats` implemented; shows lookups/hits/misses/collisions.
- Kitty “CSI u” decoding implemented with helper and unit tests.
 - Mouse support removed entirely; editor is strictly keyboard‑only (no enable/disable commands).
 - Docs added: Upgrading guide and terminal compatibility notes.
 - CI: Quiet mode by default (`UEMACS_VERBOSE_TESTS=1` for verbose); keymap tests run in CI.
 - Theme‑aware highlights implemented: current line and ruler use terminal‑inherited styles (underline/bold/dim) with `hilinestyle`/`rulerstyle` and avoid reverse‑video; configurable and persisted.
 - Microbench targets (key lookup, UTF‑8 decode, search) build and run; `bench_editor` requires a TTY.
 - Expect scripts corrected and runnable under PTY; integration harness skips them gracefully when no PTY.

## Status

All high‑value items for the keyboard‑only scope are complete. Project is stable and packaged; ongoing maintenance only.

- Keymap Modernization: describe/list bindings enumerate modern keymaps; no linear scans.
- Terminal Input: ESC/CSI u normalized into a single `key_event` decode path with unit tests.
- Interactive Tests: PTY‑backed expect runner available; skips are explicit on non‑PTY.
- Terminal Features: mouse interactions out‑of‑scope; editor is keyboard‑only.
- Documentation & UX: README snippets; upgrading and terminal notes included.
 - Undo persistence: intentionally deferred (stub present); not in current scope.

## CI & Tooling
 - Completed: Quiet test mode by default; verbose via `UEMACS_VERBOSE_TESTS=1`.
 - Completed: Always run `keymap_tests`; expect tests run only when PTY available (optional `RUN_EXPECT=1` PTY wrapper).
 - Completed: Microbench targets (key lookup, UTF‑8 decode, search) added and reported.
 - Note: `bench_editor` needs a real TTY; skipped in headless CI.

## Code Hygiene
 - Maintained: warnings are clean for core paths under `-Wall -Wextra -Wpedantic`; minor cosmetic warnings remain in config code (`eval.c`). No C++isms.

## Acceptance Criteria (Met)
 - Unit/integration tests pass locally; interactive expect runs under PTY in CI when enabled.
 - Legacy keytab removed from runtime lookups; modern keymaps are the single source of truth.
 - `keymap-stats` reports accurate metrics; documentation updated.
 - CSI u decoding implemented and covered by tests and brief docs.
 - Mouse interactions intentionally unsupported; editor is keyboard‑only.

No remaining TODO items.

## Theme‑Aware Highlights (Completed)

- Highlights inherit terminal theme via ANSI SGR (underline/bold/dim); no fixed RGB required.
- Capability aware and degrades gracefully; user configurable via `hilinestyle`/`rulerstyle` with persistence.
- Current line and column ruler implemented without reverse‑video.

## Font Smoothing (Status)

- Font rendering, antialiasing, and hinting are handled by the terminal emulator (Pango/FreeType/CoreText/DirectWrite), not by μEmacs.
- Therefore smoothing is inherited from the terminal’s configuration; TUI apps cannot reliably toggle it via ANSI/termcap.
- Action: none in μEmacs. Users should configure smoothing in their terminal (Kitty/WezTerm/Alacritty/GNOME Terminal, etc.).


## Owner & Timeline
- Owner: Core maintainers
- Target: Delivered; maintenance mode

This TODO is complete and actionable. Each bullet is independently shippable and trims the project toward a fast, modern, Linux‑only μEmacs while preserving its classic feel.
